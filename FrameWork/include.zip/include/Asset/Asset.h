﻿#pragma once
#include "../Share/Object.h"

class CAsset
{
public:
	CAsset();
	virtual ~CAsset();
};

