﻿#pragma once
#include "Mesh.h"
class CStaticMesh : public CMesh
{
public:
	CStaticMesh();
	~CStaticMesh();
};