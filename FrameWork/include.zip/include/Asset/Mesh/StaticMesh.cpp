﻿#include "StaticMesh.h"

CStaticMesh::CStaticMesh()
{
}

CStaticMesh::~CStaticMesh()
{
}
