﻿#include "Asset.h"

CAsset::CAsset()
{
}

CAsset::~CAsset()
{
}
