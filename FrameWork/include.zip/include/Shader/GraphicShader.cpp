﻿#include "Shader.h"

CShader::CShader()
{
}

CShader::~CShader()
{
}
