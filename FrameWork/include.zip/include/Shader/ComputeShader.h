﻿#pragma once
#include "Shader.h"
class CComputeShader :
    public CShader
{
};

